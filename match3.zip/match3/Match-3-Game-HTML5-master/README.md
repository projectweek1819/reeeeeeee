# Match-3 Game HTML5
A Match-3 game like Bejeweled and Candy Crush Saga with HTML5 Canvas and JavaScript.

This is a code example that belongs to the article: [How To Make A Match-3 Game With HTML5 Canvas](http://rembound.com/articles/how-to-make-a-match3-game-with-html5-canvas)

[![How To Make A Match-3 Game With HTML5 Canvas](screenshot.png?raw=true)](http://rembound.com/articles/how-to-make-a-match3-game-with-html5-canvas)

# License
Copyright (c) 2015 Rembound.com

This program is free software: you can redistribute it and/or modify  
it under the terms of the GNU General Public License as published by  
the Free Software Foundation, either version 3 of the License, or  
(at your option) any later version.

This program is distributed in the hope that it will be useful,  
but WITHOUT ANY WARRANTY; without even the implied warranty of  
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the  
GNU General Public License for more details.  

You should have received a copy of the GNU General Public License  
along with this program.  If not, see http://www.gnu.org/licenses/.